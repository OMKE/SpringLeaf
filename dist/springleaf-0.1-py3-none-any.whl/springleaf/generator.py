



from springleaf.utils.java_parser import JavaParser


class Generator:
    def __init__(self):
        self.java_parser = JavaParser()

    def generate(self):
        pass

    """
    #TODO
    @desc:
        Selects a directory structure
    """

    def select_directory_structure(self):
        pass
