

class QuestionNotCreatedException(Exception):
    pass
